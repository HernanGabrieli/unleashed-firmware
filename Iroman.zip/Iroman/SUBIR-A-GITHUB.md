# Cómo subir este paquete al repositorio Iroman (3 pasos)

1. **Creá el repositorio** en GitHub: https://github.com/new → nombre `Iroman` → Private → *Create repository* (sin README).
2. **Subí los archivos** (elegí una opción):
   - **Con terminal** (recomendado, sube también las carpetas ocultas como `.claude-plugin`):
     ```
     cd Iroman
     git init -b main
     git add .
     git commit -m "AIXCEEDS team plugin"
     git remote add origin https://github.com/HernanGabrieli/Iroman.git
     git push -u origin main
     ```
   - **Desde el navegador**: en el repositorio vacío, *uploading an existing file* → arrastrá **todo el contenido** de la carpeta `Iroman`.
     En Mac, antes apretá `Cmd + Shift + .` en Finder para ver la carpeta oculta `.claude-plugin`: es obligatoria.
3. **Instalá el equipo**:
   - **Claude Code**: `/plugin marketplace add HernanGabrieli/Iroman` y después `/plugin install aixceeds-team@aixceeds`
   - **Cowork**: abrí el archivo `aixceeds-team.plugin` y aceptá.

Opcional: para que Claude trabaje directo en el repositorio, dale acceso a la app de Claude en https://claude.ai/connect-github.
